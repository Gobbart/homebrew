# soulbound-styleguide
Homebrewery CSS for [Soulbound-style documents](https://homebrewery.naturalcrit.com/share/P2vf38iZgLn2): https://homebrewery.naturalcrit.com/share/P2vf38iZgLn2.
